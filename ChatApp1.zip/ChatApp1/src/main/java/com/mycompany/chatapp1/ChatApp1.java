/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.chatapp1;

/**
 *
 * @author RC_Student_lab
 */
public class ChatApp1 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
